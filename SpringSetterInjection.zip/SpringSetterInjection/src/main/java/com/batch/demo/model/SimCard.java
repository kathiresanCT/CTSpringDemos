package com.batch.demo.model;

public class SimCard {

	void processSim() {
		System.out.println("processing...");
	}
	public SimCard() {
		// TODO Auto-generated constructor stub
	}

}
