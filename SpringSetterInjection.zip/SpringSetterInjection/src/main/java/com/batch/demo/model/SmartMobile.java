package com.batch.demo.model;

public class SmartMobile extends Mobile {

	private String mobileName;
	private int price;
	private SimCard sim;
	
	public SimCard getSim() {
		return sim;
	}
	public void setSim(SimCard sim) {
		this.sim = sim;
	}
	
	public String getMobileName() {
		return mobileName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}
	
	
	
	
//	@Override
//	public String toString() {
//		return "SmartMobile [mobileName=" + mobileName + ", price=" + price +" SIm card:"+this.sim+"]";
//	}
	public SmartMobile(String mobileName, int price) {
		super();
		this.mobileName = mobileName;
		this.price = price;
	}
	public SmartMobile() {
		// TODO Auto-generated constructor stub
	}

	public void videoCall() {
		System.out.println("calling...");
	}
}
