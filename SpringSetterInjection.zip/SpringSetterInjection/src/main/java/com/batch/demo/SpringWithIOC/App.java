package com.batch.demo.SpringWithIOC;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.batch.demo.model.Mobile;
import com.batch.demo.model.SmartMobile;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Mobile m1, m=null;
    	ApplicationContext app=new ClassPathXmlApplicationContext("spring-config.xml");
    	m=(SmartMobile)app.getBean("myBean");    	
    	System.out.println(m);
    	m1=(SmartMobile)app.getBean("myBean");    	
    	System.out.println(m1);
    }
}
