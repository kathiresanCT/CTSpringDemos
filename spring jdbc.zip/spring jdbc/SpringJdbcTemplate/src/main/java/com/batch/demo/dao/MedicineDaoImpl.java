package com.batch.demo.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.batch.demo.model.Medicine;

@Component("medDao")
public class MedicineDaoImpl {

	public MedicineDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	private JdbcTemplate jdbc = null;

	private DataSource dataSource;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbc = new JdbcTemplate(dataSource);
	}

	public Medicine findById(int id) {

		String sql = "SELECT * FROM Medicine WHERE med_id = ?";
		Connection conn = null;

		try {
			Medicine medicine = null;
			medicine = (Medicine) jdbc.queryForObject(sql, new Object[] { 101 }, new MedicineRowMapper());

			return medicine;
		} catch (Exception sq) {
			throw new RuntimeException(sq);
		}

	}

	class MedicineRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        	Medicine medicine = new Medicine();
        	medicine.setmId(rs.getInt("med_id"));
        	medicine.setMedicineName(rs.getString("med_name"));
        	medicine.setQuantity(rs.getInt("qty"));
            return medicine;
        }
	}
}
