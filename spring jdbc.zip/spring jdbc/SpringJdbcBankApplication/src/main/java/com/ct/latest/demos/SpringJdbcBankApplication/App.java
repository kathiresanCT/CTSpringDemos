package com.ct.latest.demos.SpringJdbcBankApplication;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ct.latest.demos.SpringJdbcBankApplication.model.Account;
import com.ct.latest.demos.SpringJdbcBankApplication.service.AccountServiceImpl;
import com.ct.latest.demos.SpringJdbcBankApplication.service.IAccountService;

public class App 
{
//	@Autowired
//	private static IAccountService accountService;

	public static void main( String[] args )
    {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
		IAccountService service=ctx.getBean("accountService",AccountServiceImpl.class);
		Account account =new Account(1002,"Arjun","kumar",4456.66f,20000,"6798798345");
		service.createAccount(account);
    }
}
