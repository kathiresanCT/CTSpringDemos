package com.ct.latest.demos.SpringJdbcBankApplication.service;

import java.util.List;

import javax.sql.DataSource;

import com.ct.latest.demos.SpringJdbcBankApplication.model.Account;

public interface IAccountService {

	public void createAccount(Account account);
	public boolean deleteAccount(int accountId);
	public List<Account> getAllAccounts();
	public Account getAccountDetailsByName(String name);
	public Account getAccountDetailsById(int accountId);
	public boolean updateDetailsByName(String name);
	public boolean updateDetailsById(String name);
	
	}
