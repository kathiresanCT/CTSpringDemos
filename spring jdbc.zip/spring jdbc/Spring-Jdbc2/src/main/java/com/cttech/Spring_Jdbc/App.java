package com.cttech.Spring_Jdbc;

import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cttech.dao.JdbcDaoImpl;
import com.cttech.model.Patient;

/**
 * Hello world!
 *
 */
public class App 
{
	int x,y;
    public static void main( String[] args ) throws SQLException
    {
     //   Patient p=new JdbcDaoImpl().getPatent(1);
    	ApplicationContext apctx=new ClassPathXmlApplicationContext("spring.xml");
    	JdbcDaoImpl obj= apctx.getBean("jdbcObj",JdbcDaoImpl.class);
    	Patient p=obj.getPatent(1001);
    	System.out.println(p);

    	
    }
}
