package com.batch.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.batch.demo.model.Medicine;

@Component("medDao")
public class MedicineDaoImpl {

	public MedicineDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	private DataSource ds;
	  
	@Autowired
    public void setDataSource(DataSource dataSource) {
        this.ds = dataSource;
    }
	
	public Medicine findById(int id){
		
		String sql = "SELECT * FROM Medicine WHERE med_id = ?";
		Connection conn = null;
        
		 try {
	            conn = ds.getConnection();
	            PreparedStatement ps = conn.prepareStatement(sql);
	            ps.setInt(1, id);
	            Medicine medicine=null;	
	            ResultSet rs = ps.executeQuery();
	            if (rs.next()) {
	                medicine = new Medicine(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getFloat(4));
	            }
	            return medicine;
		 }
		 catch(SQLException sq) {
			 throw new RuntimeException(sq); 
		 }
		
	}
		  
		
}
