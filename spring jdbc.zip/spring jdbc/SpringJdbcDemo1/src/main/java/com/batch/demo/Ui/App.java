package com.batch.demo.Ui;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.batch.demo.dao.MedicineDaoImpl;
import com.batch.demo.model.Medicine;

public class App 
{
    public static void main( String[] args )
    {
    	ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
    	MedicineDaoImpl md=(MedicineDaoImpl)context.getBean("medDao");
    	Medicine mm=md.findById(101);
    	System.out.println(mm);
    }
}
