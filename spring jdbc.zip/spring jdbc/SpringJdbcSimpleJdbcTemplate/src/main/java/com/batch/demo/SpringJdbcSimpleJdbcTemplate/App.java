package com.batch.demo.SpringJdbcSimpleJdbcTemplate;

import java.util.List;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
    	MedicineDaoImpl md=(MedicineDaoImpl)context.getBean("dao");
    	List<Medicine> mm=md.getAll();
    	System.out.println(mm);
    }
}
