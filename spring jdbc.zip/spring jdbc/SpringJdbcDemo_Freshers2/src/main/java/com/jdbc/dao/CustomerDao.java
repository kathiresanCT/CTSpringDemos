package com.jdbc.dao;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.jdbc.model.Customer;

public class CustomerDao {

//	private JdbcTemplate jdbcObj;
	private NamedParameterJdbcTemplate jTemplate;
	public NamedParameterJdbcTemplate getjTemplate() {
		return jTemplate;
	}
	public void setjTemplate(NamedParameterJdbcTemplate jTemplate) {
		this.jTemplate = jTemplate;
	}
	/*public JdbcTemplate getJdbcObj() {
		return jdbcObj;
	}
	public void setJdbcObj(JdbcTemplate jdbcObj) {
		this.jdbcObj = jdbcObj;
	}*/
	/*@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<Customer> getEmployeeInfo() {
		
		String qry="SELECT * FROM CUSTOMER";
	//	List<Customer> custList=jdbcObj.query(qry, new CustomerRowMapper());
		List<Customer> custList=jdbcObj.query(qry, new BeanPropertyRowMapper(Customer.class));
	//	System.out.println(custList);
		return custList;
	}*/
	/*@SuppressWarnings("unchecked")
	public Customer getCustomerById(int id){
		Customer c=null;
		String qry="SELECT * FROM CUSTOMER WHERE id=? and name=?";
		System.out.println(qry);
	//	List<Customer> custList=jdbcObj.query(qry, new BeanPropertyRowMapper(Customer.class));
		c=(Customer) jdbcObj.queryForObject(qry,new Object[] {id,"aaa"},new BeanPropertyRowMapper(Customer.class));
		System.out.println(c);
		return c;
	}
*/
	//named parameter jdbc template
	@SuppressWarnings("unchecked")
	public Customer getCustomerById(int id){
		 
		Customer c=null;
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("name", "aaa");
		paramSource.addValue("id", id);
		
		SqlRowSet rs=jTemplate.queryForRowSet("SELECT * FROM customer WHERE name = :name AND id = :id", paramSource);
		while(rs.next()) {
			c=new Customer(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
		}
		return c;
	}
	
	/*public boolean StoreCustomerInfo(Customer cust) {
		String sql="insert into customer values(?,?,?,?)";
		int status=jdbcObj.update(sql,new Object[] {cust.getId(),cust.getName(),cust.getCity(),cust.getMobile()});
		if(status==1) {
			return true;	
		}
		else {
			return false;
		}
	}*/
}
/*class CustomerRowMapper implements RowMapper<Customer>{

	@Override
	public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
		Customer c=new Customer(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
		return c;
	}
}*/



