package com.jdbc;



import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.jdbc.dao.CustomerDao;
import com.jdbc.model.Customer;

public class App 
{
    public static void main( String[] args )
    {
    
    	ApplicationContext ctx=null;
    	ctx=new ClassPathXmlApplicationContext("springConfig.xml");
    	CustomerDao cust=(CustomerDao)ctx.getBean("custDaoNamed");
    	//retrieve from db
    	//System.out.println(cust.getEmployeeInfo());
    	System.out.println(cust.getCustomerById(1001));
    	//System.out.println(cust.StoreCustomerInfo(new Customer(1005, "rrr", "Hyd","9897978987")));
    }
}




