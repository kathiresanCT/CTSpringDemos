package com.cttech.Spring_Jdbc_retrivel.dao;

import java.util.List;

import com.cttech.Spring_Jdbc_retrivel.model.Payer;

public interface IPayerDao {

	public String getPayerNamebyId(int payerId);
	public Payer getAllPayerInfById(int payerId);
	public List<Payer> getAllPayers();
	public List<String> getAllPayersName();
	public boolean addPayerDetails(Payer payer);
}
