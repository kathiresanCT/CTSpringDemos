package com.cttech.Spring_Jdbc_retrivel.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cttech.Spring_Jdbc_retrivel.model.Payer;

@Repository
public class PayerDaoImpl implements IPayerDao {

	private DataSource dataSource = null;

	private JdbcTemplate jdbcTemp = null;

	@Override
	public String getPayerNamebyId(int payerId) {
		String sql = "SELECT payer_name FROM PAYER WHERE pid=?";
		return jdbcTemp.queryForObject(sql, new Object[] { payerId }, String.class);
	}

	public DataSource getDataSource() {
		return dataSource;
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		jdbcTemp = new JdbcTemplate(dataSource);
	}

	@Override
	public Payer getAllPayerInfById(int payerId) {
		String sql = "SELECT * FROM PAYER WHERE pid=?";

		return jdbcTemp.queryForObject(sql, new Object[] { payerId }, new PayerRowMapper());
	}

	@Override
	public List<Payer> getAllPayers() {
		String sql = "SELECT * FROM PAYER";
		return jdbcTemp.query(sql, new PayerRowMapper());
	}
	@Override
	public List<String> getAllPayersName() {
		String sql = "SELECT payer_name FROM PAYER";
		
		return jdbcTemp.queryForList(sql,String.class);
		//return jdbcTemp.query(sql, new PayerRowMapper());
	}

	@Override
	public boolean addPayerDetails(Payer payer) {
		String sql="insert into Payer values(?,?,?,?)";
		int status=jdbcTemp.update(sql,new Object[] {payer.getPayerId(),payer.getPayerName(),payer.getPayerMobile(),payer.getPayerCity()});
		System.out.println(status);
		return status==1?true:false;
	}
}
