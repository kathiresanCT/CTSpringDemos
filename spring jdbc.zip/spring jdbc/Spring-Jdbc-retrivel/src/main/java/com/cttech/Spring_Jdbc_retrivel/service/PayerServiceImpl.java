package com.cttech.Spring_Jdbc_retrivel.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cttech.Spring_Jdbc_retrivel.dao.IPayerDao;
import com.cttech.Spring_Jdbc_retrivel.model.Payer;

@Component
public class PayerServiceImpl implements IPayerService {

	@Autowired
	private IPayerDao payerDao;
	
	@Override
	public String getPayerNamebyId(int payerId) {
		// TODO Auto-generated method stub
		return payerDao.getPayerNamebyId(payerId);
	}

	@Override
	public Payer getAllPayerInfById(int payerId) {
		// TODO Auto-generated method stub
		return payerDao.getAllPayerInfById(payerId);
	}

	@Override
	public List<Payer> getAllPayers() {
		// TODO Auto-generated method stub
		return payerDao.getAllPayers();
	}

	@Override
	public List<String> getAllPayersName() {
		// TODO Auto-generated method stub
		return payerDao.getAllPayersName();
	}

	 @Override
	public boolean addPayerDetails(Payer payer) {
		// TODO Auto-generated method stub
		return payerDao.addPayerDetails(payer);
	}
}
