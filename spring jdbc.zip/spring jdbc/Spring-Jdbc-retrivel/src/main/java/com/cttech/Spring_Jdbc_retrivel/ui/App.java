package com.cttech.Spring_Jdbc_retrivel.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cttech.Spring_Jdbc_retrivel.model.Payer;
import com.cttech.Spring_Jdbc_retrivel.service.IPayerService;
import com.cttech.Spring_Jdbc_retrivel.service.PayerServiceImpl;


/**
 * Hello world!
 *
 */
public class App 
{
	
	private static IPayerService payerService;
	
    public static void main( String[] args )
    {
    	ApplicationContext apctx=new ClassPathXmlApplicationContext("spring.xml");
    	payerService= apctx.getBean("payerServiceImpl",PayerServiceImpl.class);
    	//payerServiceImpl is name of class- as no name given in @component
    //	System.out.println(payerService.getPayerNamebyId(1002));  
    	//all the record of an id is needed
    	System.out.println(payerService.getAllPayerInfById(1002));
    	payerService.getAllPayers().stream().forEach(System.out::println);
    	payerService.getAllPayersName().stream().forEach(System.out::println);
    	//System.out.println((int)(Math.random()*10000));
    	boolean status =payerService.addPayerDetails(new Payer("Yash","Mumbai","7598986543",((int)(Math.random()*10000))));
    	System.out.println(status?"data stored":"not stored");
    	
    }
}
