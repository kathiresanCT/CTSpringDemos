package com.jdbc;



import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jdbc.dao.EmployeeDao;
import com.jdbc.model.Employee;

public class App 
{
    public static void main( String[] args )
    {
    
    	ApplicationContext ctx=null;
    	ctx=new ClassPathXmlApplicationContext("springConfig.xml");        
        EmployeeDao dao=(EmployeeDao)ctx.getBean("edao");  
    //    int status=dao.saveEmployee(new Employee(106,"kevin",35000));  
      //  System.out.println(status);
        System.out.println(dao.getAllEmployee());
        System.out.println(dao.getById(105));
        System.out.println(dao.getSalaryByName("kevin"));
    }
}




