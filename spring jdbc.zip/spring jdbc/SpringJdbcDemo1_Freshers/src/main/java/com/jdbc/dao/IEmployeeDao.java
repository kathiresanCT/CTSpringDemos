package com.jdbc.dao;

public interface IEmployeeDao {

}
