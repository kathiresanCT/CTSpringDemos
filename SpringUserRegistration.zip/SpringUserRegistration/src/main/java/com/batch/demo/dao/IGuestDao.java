package com.batch.demo.dao;

import javax.sql.DataSource;

import com.batch.demo.model.GuestUser;

public interface IGuestDao {

	public void SetDataSource(DataSource ds);
	public void registerGuestUser(GuestUser user);
	public GuestUser getUserById(int userId);
}