package com.batch.demo.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.batch.demo.model.GuestUser;

public class GuestUserRowMapper implements RowMapper<GuestUser> {

	public GuestUser mapRow(ResultSet rs, int rowNum) throws SQLException {
		GuestUser user=new GuestUser();
		user.setUserId(rs.getInt(1));
		user.setUserName(rs.getString(2));
		user.setFirstName(rs.getString(3));
		user.setLastName(rs.getString(4));
		user.setMobile(rs.getInt(5));
		return user;
	}

	

}
