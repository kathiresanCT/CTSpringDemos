package com.batch.demo.SpringUserRegistration;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.batch.demo.model.GuestUser;
import com.batch.demo.service.GuestServiceImpl;
import com.batch.demo.service.IGuestService;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
    	IGuestService guestService=ctx.getBean("guestService",GuestServiceImpl.class);
    	//GuestUser user=new GuestUser(10001, "Vinith123","vinith" ,"kumar", 9876655);
    	//guestService.registerGuestUser(user);
    	GuestUser user= guestService.getUserById(10001);
    	System.out.println(user);
    }
}

