package com.batch.demo.service;

import com.batch.demo.model.GuestUser;

public interface IGuestService {

	public void registerGuestUser(GuestUser user);
	public GuestUser getUserById(int userId);
	
}