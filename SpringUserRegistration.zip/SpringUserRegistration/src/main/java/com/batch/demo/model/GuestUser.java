package com.batch.demo.model;

public class GuestUser {

	private int userId;
	private String userName;
	private String firstName;
	private String lastName;
	private int mobile;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getMobile() {
		return mobile;
	}

	public void setMobile(int mobile) {
		this.mobile = mobile;
	}

	public GuestUser(int userId, String userName, String firstName, String lastName, int mobile) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobile = mobile;
	}

	public GuestUser() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "GuestUser [userId=" + userId + ", userName=" + userName + ", firstName=" + firstName + ", lastName="
				+ lastName + ", mobile=" + mobile + "]";
	}

}
