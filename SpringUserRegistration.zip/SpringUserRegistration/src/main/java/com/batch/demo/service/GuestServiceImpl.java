package com.batch.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.batch.demo.dao.GuestDaoImpl;
import com.batch.demo.model.GuestUser;

@Component("guestService")
public class GuestServiceImpl implements IGuestService {

	@Autowired
	private GuestDaoImpl dao;
	
	public void registerGuestUser(GuestUser user) {
		//apply some business logic
		dao.registerGuestUser(user);
	}

	public GuestUser getUserById(int userId) {
		return dao.getUserById(userId);
	}

}
