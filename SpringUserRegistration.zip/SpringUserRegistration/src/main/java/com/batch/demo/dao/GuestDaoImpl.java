package com.batch.demo.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.batch.demo.model.GuestUser;

@Component
public class GuestDaoImpl implements IGuestDao{

	private DataSource ds;
	private JdbcTemplate jdbcTemp;
	
	public void registerGuestUser(GuestUser user) {
	//code to store data in db
		String qry="INSERT INTO GuestAccout values(?,?,?,?,?)";
		int status=jdbcTemp.update(qry,user.getUserId(),user.getUserName(),user.getFirstName(),user.getLastName(),user.getMobile());
		
		System.out.println(status+ " stored");
		return;
	}

	@Autowired
	public void SetDataSource(DataSource ds) {
		this.ds=ds;
		this.jdbcTemp=new JdbcTemplate(ds);
	}

	public GuestUser getUserById(int userId) {
		String sql = "SELECT * FROM GuestAccout WHERE user_id=? ";
		return jdbcTemp.queryForObject(sql, new Object[] {userId}, new GuestUserRowMapper());
	}

}
