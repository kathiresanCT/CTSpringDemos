package com.batch.demo.SpringApplicationContext;

public class Room {
	private int id;
	public void setId(int id) {
		this.id = id;
	}
	public int getId() {
		return id;
	}
	public Room() {
	System.out.println("hi");
	}
}
