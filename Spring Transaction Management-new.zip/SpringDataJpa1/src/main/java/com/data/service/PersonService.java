package com.data.service;

import java.util.List;

import com.data.model.Person;

public interface PersonService {
	void add(Person person);

	List<Person> listPersons();
}
