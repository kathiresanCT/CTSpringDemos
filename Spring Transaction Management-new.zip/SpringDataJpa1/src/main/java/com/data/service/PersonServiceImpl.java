package com.data.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.data.dao.PersonDao;
import com.data.model.Person;
@Service
@Transactional
public class PersonServiceImpl implements PersonService {

	@Autowired
	private PersonDao personCrud;
	
	@Override
	public void add(Person person) {
		System.out.println(personCrud.save(person));
	}

	@Override
	public List<Person> listPersons() {
		return (List<Person>)personCrud.findAll();
	}

}
