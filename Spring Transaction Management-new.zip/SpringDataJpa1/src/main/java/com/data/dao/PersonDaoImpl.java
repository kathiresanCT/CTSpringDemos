/*package com.data.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.data.dao.PersonDao;
import com.data.model.Person;
@Repository
public class PersonDaoImpl implements PersonDao {

}
*/