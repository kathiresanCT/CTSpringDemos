package com.data.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.data.model.Person;

public interface PersonDao extends CrudRepository<Person, Integer> {
    
} 