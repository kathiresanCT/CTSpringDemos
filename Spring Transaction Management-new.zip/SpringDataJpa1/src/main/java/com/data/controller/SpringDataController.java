package com.data.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.data.model.Person;
import com.data.service.PersonService;

@Controller
public class SpringDataController {
	@Autowired
	private PersonService pserv;
	
	@RequestMapping("/")
	public ModelAndView home() {
	    List<Person> listPerson = pserv.listPersons();
	    ModelAndView mav = new ModelAndView("index");
	    mav.addObject("listPerson", listPerson);
	    return mav;
	}
	@RequestMapping("/new")
	public String newPersonForm(Model m) {
	    Person person = new Person();
	    m.addAttribute("person", person);
	    return "new_person";
	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveCustomer(@ModelAttribute("person") Person person) {
		pserv.add(person);
	    return "redirect:/";
	}


}
