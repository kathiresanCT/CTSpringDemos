package com.data.web.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(name = "findByfName",
query = "select u from Flight u where u.fName =:fname")
public class Flight {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int flightNo;
	private String fName;
	private int seats;
	private int engineCapacity;
	
	public Flight() {
		// TODO Auto-generated constructor stub
	}

	public int getFlightNo() {
		return flightNo;
	}

	public void setFlightNo(int flightNo) {
		this.flightNo = flightNo;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public int getSeats() {
		return seats;
	}

	public void setSeats(int seats) {
		this.seats = seats;
	}

	public int getEngineCapacity() {
		return engineCapacity;
	}

	public void setEngineCapacity(int engineCapacity) {
		this.engineCapacity = engineCapacity;
	}

	public Flight(int flightNo, String fName, int seats, int engineCapacity) {
		super();
		this.flightNo = flightNo;
		this.fName = fName;
		this.seats = seats;
		this.engineCapacity = engineCapacity;
	}

	@Override
	public String toString() {
		return "Flight [flightNo=" + flightNo + ", fName=" + fName + ", seats=" + seats + ", engineCapacity="
				+ engineCapacity + "]";
	}
	
	
}
