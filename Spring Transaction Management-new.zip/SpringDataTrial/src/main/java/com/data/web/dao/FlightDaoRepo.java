package com.data.web.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.data.web.model.Flight;

public interface FlightDaoRepo extends JpaRepository<Flight,Integer> {

	public Flight findByfName(@Param("fname") String name);
}
