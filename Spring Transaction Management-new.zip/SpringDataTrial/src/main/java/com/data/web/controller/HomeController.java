package com.data.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.data.web.model.Flight;
import com.data.web.service.IFlightService;
@Controller
public class HomeController {

	@Autowired
	private IFlightService serv;
	
	@RequestMapping("/")
	public String getHome() {
		return "home";
	}
	
	@GetMapping("/store")
	public String getStorePage(Model m) {
		m.addAttribute("flight",new Flight());
		return "store";
	}
	@PostMapping("/store")
	public String storeData(@ModelAttribute("flight") Flight flight,Model m) {
		Flight fht=serv.store(flight);
		m.addAttribute("flight", fht);
		return "single";
	}
	
	@GetMapping("/getAll")
	public String getAllStore(Model m) {
		System.out.println("in get all");
		List<Flight> fList=serv.getAll();
		System.out.println(fList.size());
		m.addAttribute("flist",fList);
		return "getAll";
	}
	@GetMapping("/getByName")
	public String getAllStore(@RequestParam("name") String name,Model m) {
		System.out.println(name);
		Flight flt=serv.findByfName(name);
		System.out.println(flt);
		m.addAttribute("flight",flt);
		return "single";
	}
}
