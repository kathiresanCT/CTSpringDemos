package com.data.web.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.data.web.dao.FlightDaoRepo;
import com.data.web.model.Flight;

@Service
public class FlightService implements IFlightService{

	@Autowired
	private FlightDaoRepo repository;

	@Override
	public Flight store(Flight flight) {
		return repository.save(flight);
	}

	@Override
	public List<Flight> getAll() {
		return repository.findAll();
	}
	@Override
	public Flight findByfName(String name) {
		return repository.findByfName(name);
	}
}
