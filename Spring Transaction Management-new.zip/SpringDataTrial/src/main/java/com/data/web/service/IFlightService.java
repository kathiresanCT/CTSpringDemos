package com.data.web.service;

import java.util.List;

import com.data.web.model.Flight;

public interface IFlightService {

	public Flight store(Flight flight);
	public List<Flight> getAll();
	public Flight findByfName(String name);
}
