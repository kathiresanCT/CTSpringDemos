package com.data.crud.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.data.crud.model.Product;

public interface IProductJpaDaoRepo extends JpaRepository<Product,Integer>{

	@Query("SELECT f FROM Product f WHERE LOWER(f.prodName) = LOWER(:name)")
	public Product retrieveByName(@Param("name") String name);
	public Product findByDesciption(@Param("desc") String desc);
	
}
