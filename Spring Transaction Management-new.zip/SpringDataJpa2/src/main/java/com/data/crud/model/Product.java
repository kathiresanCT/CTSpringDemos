package com.data.crud.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(name = "prod.findByDesciption",
query = "select u from Product u where u.desciption =:desc")
public class Product {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="prodid")
	private int prodId;
	private String prodName;
	private int qty;
	private String desciption;
	private float price;
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public String getDesciption() {
		return desciption;
	}
	public void setDesciption(String desciption) {
		this.desciption = desciption;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
	public Product() {
		// TODO Auto-generated constructor stub
	}
	public Product(int prodId, String prodName, int qty, String desciption, float price) {
		super();
		this.prodId = prodId;
		this.prodName = prodName;
		this.qty = qty;
		this.desciption = desciption;
		this.price = price;
	}
	
}
