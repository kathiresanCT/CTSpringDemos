package com.data.crud.service;

import java.util.List;
import java.util.Optional;

import com.data.crud.model.Product;

public interface IProductService {

	public Product addProduct(Product product);
	public List<Product> getAllProducts();
	public Product getAllProductById(int pId);
	public Product getProductByName(String name);
	public Product getProductByDesc(String desc);
}
