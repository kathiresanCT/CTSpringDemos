package com.data.crud.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.data.crud.model.Product;
import com.data.crud.service.IProductService;

@Controller
public class ProductController {
	@Autowired
	private IProductService serv;
	
	@RequestMapping("/")
	public ModelAndView getHome() {
		return new ModelAndView("home");
	}
	@GetMapping("add")
	public ModelAndView getAddProductPage() {
		ModelAndView mv=new ModelAndView("add");
		mv.addObject("prod",new Product());
		return mv;
	}
	@PostMapping("add")
	public ModelAndView addProduct(@ModelAttribute("prod") Product prod) {
		Product product=serv.addProduct(prod);
		ModelAndView mv=null;
		if(!product.equals(null))
		mv=new ModelAndView("add");
		mv.addObject("msg","Product Added!!!");
		return mv;
	}
	@RequestMapping("getById")
	public ModelAndView getProductById(@RequestParam("id") int id) {
		Product product=null;
		ModelAndView mv=null;
		product=serv.getAllProductById(id);
		mv=new ModelAndView("single");
		mv.addObject("prod",product);
		return mv;
	}
	@RequestMapping("getByName")
	public ModelAndView getProductByName(@RequestParam("name") String name) {
		Product product=null;
		ModelAndView mv=null;
		product=serv.getProductByName(name);
		mv=new ModelAndView("single");
		mv.addObject("prod",product);
		return mv;
	}
	@RequestMapping("getByDesc")
	public ModelAndView getProductByDesc(@RequestParam("desc") String desc) {
		Product product=null;
		ModelAndView mv=null;
		product=serv.getProductByDesc(desc);
		mv=new ModelAndView("single");
		mv.addObject("prod",product);
		return mv;
	}
}
