package com.data.crud.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.data.crud.dao.IProductJpaDaoRepo;
import com.data.crud.model.Product;

@Service
public class ProductServiceImpl implements IProductService{

	@Autowired
	private IProductJpaDaoRepo repo;
	
	@Override
	public Product addProduct(Product product) {
		return repo.save(product);
	}

	@Override
	public List<Product> getAllProducts() {
		return (List<Product>) repo.findAll();
	}

	@Override
	public Product getAllProductById(int pId) {
		return repo.findOne(pId);
	}

	@Override
	public Product getProductByName(String name) {
			return repo.retrieveByName(name);
	}
	@Override
	public Product getProductByDesc(String desc) {
		return repo.findByDesciption(desc);
		
	}
}
