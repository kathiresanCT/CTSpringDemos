package com.batch.demo.SpringApplicationContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("bank1")
@Scope(value="prototype")
public class Bank {

	@Value(value="10")
	private int bankId;
	@Value(value="HDFC")
	private String bankName;

	@Autowired(required=false)
	private Department dept;
	
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	
	public Bank() {
		System.out.println("constr called");
	}
	
	public int getBankId() {
		return bankId;
	}

	public void setBankId(int bankId) {
		this.bankId = bankId;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

//	@Override
//	public String toString() {
//		return "Bank [bankId=" + bankId + ", bankName=" + bankName + "]";
//	}

	public Bank(int bankId, String bankName) {
		super();
		this.bankId = bankId;
		this.bankName = bankName;
	}

	
}
