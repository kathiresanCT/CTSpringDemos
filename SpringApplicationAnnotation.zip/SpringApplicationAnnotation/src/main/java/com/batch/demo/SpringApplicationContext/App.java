package com.batch.demo.SpringApplicationContext;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
       Bank bank=(Bank)ctx.getBean("bank1");
       System.out.println(bank);
       System.out.println(bank.getBankId());
       System.out.println(bank.getBankName());
//       Bank bank1=(Bank)ctx.getBean("bank1");
//       System.out.println(bank1);
       System.out.println("dept : "+bank.getDept());
    }
}



