package com.batch.demo.SpringApplicationContext;

import org.springframework.stereotype.Component;

@Component(value= "dept1")
public class Department {

	public Department() {
	
		System.out.println("dept constr called");
	
	}
	
}
