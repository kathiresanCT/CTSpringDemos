package com.batch.demo.SpringApplicationContext;

public class Hospital {

	private int hId;
	private String hospName;
	private Room room;
	public Room getRoom() {
		return room;
	}
	public void setRoom(Room room) {
		this.room = room;
	}
	
	public int gethId() {
		return hId;
	}
	public void sethId(int hId) {
		this.hId = hId;
	}
	public String getHospName() {
		return hospName;
	}
	public void setHospName(String hospName) {
		this.hospName = hospName;
	}
	
	public Hospital() {
		System.out.println("constr called");
	}
	public Hospital(int hId, String hospName) {
		this.hId = hId;
		this.hospName = hospName;
	}
	@Override
	public String toString() {
		return "Hospital [hId=" + hId + ", hospName=" + hospName + "]";
	}
	
}
