package com.batch.demo.SpringApplicationContext;

public class Room {

}
