package com.batch.demo.SpringApplicationContext;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
        Hospital h=(Hospital)ctx.getBean("hospital");
        System.out.println(h.gethId()+"   "+h.getHospName());
        System.out.println(h.getRoom());
//        Hospital h1=(Hospital)ctx.getBean("hospital");
//        System.out.println(h1.gethId()+"   "+h1.getHospName());
    
    }
}



