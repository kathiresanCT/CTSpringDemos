package com.cttech;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

public class Customer {
	
	@NotEmpty(message="its mandatory")
	private String name;
	@NotEmpty(message="mobile is mandatory")
	@Pattern(regexp="[\\d] {10}",message="mobile number should be 10 digits")
	private String mobile;
	@NotEmpty(message="email is mandatory")
	private String email;
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mbile) {
		this.mobile = mbile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Customer(String name, String mbile, String email) {
		super();
		this.name = name;
		this.mobile = mbile;
		this.email = email;
	}
	
	
}
