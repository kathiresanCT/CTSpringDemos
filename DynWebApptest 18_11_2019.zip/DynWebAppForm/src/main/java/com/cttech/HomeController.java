package com.cttech;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("user")
public class HomeController {

	Map <String , Customer> custData=null;
	
	public HomeController() {
	custData=new HashMap<String, Customer>();	
	}
	
	@RequestMapping(value= {"/","homepage","home.aspx","home.php"})
	public String displayHomePage() {
		return "home";
	}
	@RequestMapping("register")
	public String displayRegisterPage(Model m) {
		m.addAttribute("cust",new Customer());
		return "registerPage";
	}
	@RequestMapping(value="register",method=RequestMethod.POST)
	public String store(Model m,@Valid @ModelAttribute("cust") Customer customer,BindingResult br) {
		String path=null;
		if(br.hasErrors()) {
			path="registerPage";
		}
		else {
		System.out.println(customer);
		m.addAttribute("custName","Mr. "+customer.getName());
		path="success";
		}
		return path;
	}
	
	//modelAttribute
	@RequestMapping("get")//method is get
	public String getData(@RequestParam("name") String name,@RequestParam("city") String city,Model m) {
		System.out.println(name);
		m.addAttribute("custName","Mr. "+name+" "+city);
		return "success";
	}
	
	
}
