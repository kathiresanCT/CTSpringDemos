package com.cttech;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("user")
public class HomeController {

	@RequestMapping(value= {"homepage","home.aspx","home.php"})
	public String displayHomePage() {
		return "home";
	}
	
}
