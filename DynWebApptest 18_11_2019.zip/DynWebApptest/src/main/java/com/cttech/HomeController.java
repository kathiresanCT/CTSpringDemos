package com.cttech;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeController {

	Map<Integer,Customer> custData=null;
	public HomeController() {
		System.out.println("controller called...");
	custData=new HashMap<Integer, Customer>();
	}
	@Autowired
    private JavaMailSender mailSender;

	@RequestMapping(value= {"/","homepage","home.aspx","home.php"})
	//@RequestMapping("/")
	public String displayHomePage() {
		/*SimpleMailMessage emailObj = new SimpleMailMessage();
		emailObj.setTo(toAddress);
		emailObj.setSubject(emailSubject);
		emailObj.setText(emailBody);*/
/*		mailSender.send(new MimeMessagePreparator() {
			  public void prepare(MimeMessage mimeMessageObj) throws MessagingException {
			    MimeMessageHelper messageObj = new MimeMessageHelper(mimeMessageObj, true, "UTF-8");
			    messageObj.setFrom("kathiresan.natarajan@citiustech.com");
			    messageObj.setTo("kathirkathir2006@gmail.com");
			    messageObj.setSubject("Test File");
			    messageObj.setText("<strong>See The Attached</strong>", true);
			   // messageObj.addAttachment("Template.doc", new File("Template.doc"));
			  }
			});*/
		return "home";
	}
	@RequestMapping(value="register",method=RequestMethod.GET)
	//@PostMapping("register")
	public String displayRegisterPage(Model m) {
		List<String> cityList=Arrays.asList("Mumbai","Pune","Hyderabad","Chennai");
		m.addAttribute("cityList",cityList);
		m.addAttribute("customer", new Customer());
		return "register";
	}
	@RequestMapping(value="register",method=RequestMethod.POST)
	//@PostMapping("register")
	public String storeCustomer(Model m,@Valid @ModelAttribute("customer") Customer cust,BindingResult br) {
		String view=null;
		if(br.hasErrors())
		{
			view="register";
		}
		else
		{
			view="success";
			custData.put(cust.getCustId(),cust);
		}
		
		return view;
	}
}
