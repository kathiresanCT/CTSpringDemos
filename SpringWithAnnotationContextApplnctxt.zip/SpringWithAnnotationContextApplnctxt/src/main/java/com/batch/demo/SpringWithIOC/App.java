package com.batch.demo.SpringWithIOC;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.batch.demo.model.Mobile;
import com.batch.demo.model.SmartMobile;

/**
 * Hello world!
 *
 */

public class App 
{
public void get() {
	System.out.println("hi");
}
	public static void main( String[] args )
    {
		Mobile m=null;
    	AnnotationConfigApplicationContext annotCtx=new AnnotationConfigApplicationContext();
    	annotCtx.register(SmartMobile.class);
    	 	annotCtx.refresh();
    	m=(SmartMobile)annotCtx.getBean(SmartMobile.class);
    	m.Search("hiiii");
    		
    }
}
