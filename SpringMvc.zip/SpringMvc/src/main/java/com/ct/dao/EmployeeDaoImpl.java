package com.ct.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.ct.model.Employee;

@Repository // @component
public class EmployeeDaoImpl {

	ArrayList<Employee> empList=new ArrayList<Employee>();
	
	public String addEmployee(Employee emp) {
		empList.add(emp);
		return "data of "+emp.getName()+" is added";
	}
}
