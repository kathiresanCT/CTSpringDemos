package com.batch.demo.model;

import org.springframework.stereotype.Component;

@Component("sam")
public class Sample {

	public Sample() {
		System.out.println("hiiii");
	}

}
