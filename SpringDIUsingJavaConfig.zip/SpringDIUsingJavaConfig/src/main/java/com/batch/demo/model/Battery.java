package com.batch.demo.model;

public class Battery {

	public Battery() {
		// TODO Auto-generated constructor stub
	}

}
