package com.batch.demo.SpringWithIOC;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import com.batch.demo.model.Battery;
import com.batch.demo.model.SmartMobile;

// Spring that this is the core Spring configuration file 
@Configuration
@PropertySource("classpath:BeanData.properties")
@ComponentScan(basePackages="com.batch.demo.model")
public class AppConfig {

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
		return new PropertySourcesPlaceholderConfigurer();
	}
	
//	@Bean//(name="sm")
//	public SmartMobile sm() {
//		return new SmartMobile();
//	}

	@Bean(name="smart")
	@Scope("prototype")
	public SmartMobile smartMobile() {
		return new SmartMobile(battery());
	}
	
	@Bean
	//@Scope("prototype")
	public Battery battery() {
		return new Battery(); 
	}
}
