package com.batch.demo.SpringWithIOC;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.batch.demo.model.Sample;
import com.batch.demo.model.SmartMobile;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
    	SmartMobile ss=(SmartMobile)context.getBean("smart");
    	System.out.println("first "+ss);
    	System.out.println("mobile name "+ss.getMobileName());
    	System.out.println("mobile version "+ss.getVersion());	
    	System.out.println("first "+ss.getBattery());
    	SmartMobile ss1=(SmartMobile)context.getBean("smart");
    	System.out.println("second "+ss1);
    	System.out.println("second "+ss1.getBattery());
    	Sample s=(Sample)context.getBean("sam");
    	System.out.println(s);
    	/*
    	 * AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
    	 * context.register(AppConfig.class);
    	 * ctx.register(AppConfig.class, OtherConfig.class);
    	 * */
    }
}
