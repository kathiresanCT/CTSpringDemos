package com.batch.demo.model;

import org.springframework.beans.factory.annotation.Value;

public class SmartMobile {

	@Value("HTC")
	private String mobileName;
	@Value("${version}")
	private int version;
	private Battery battery;
	
	public SmartMobile(Battery battery){
		this.battery=battery;
	}
	
	public Battery getBattery() {
		return battery;
	}
	public void setBattery(Battery battery) {
		this.battery = battery;
	}
	
	public String getMobileName() {
		return mobileName;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}
		
	public SmartMobile() {
		// TODO Auto-generated constructor stub
	}

	public void videoCall() {
		System.out.println("calling...");
	}
	public SmartMobile(String mobileName, int version) {
		super();
		this.mobileName = mobileName;
		this.version = version;
	}
//	@Override
//	public String toString() {
//		return "SmartMobile [mobileName=" + mobileName + ", version=" + version +" battery "+this.battery+"]";
//	}
//	
}
