/*package com.cttech.controller;

import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cttech.model.Customer;
import com.cttech.service.ICutomerService;

@RestController
public class HomeRestController {


	@Autowired
	private ICutomerService custServ;

	@RequestMapping(value= {"/","homepage","home.aspx","home.php"})
	public String displayHomePage() {
		return "home";
	}
	//@RequestParam(defaultValue = "test") or req=false
	//@PathVariable(required = false)
	@RequestMapping(value="register/{user}",method=RequestMethod.GET)//no use
	public String displayRegisterPage(@PathVariable("user") String name) {
		List<String> cityList=Arrays.asList("Mumbai","Pune","Hyderabad","Chennai");
		cityList.contains(name);
		return "my city is "+name+" confirmed";
	}
	@RequestMapping(value="register",method=RequestMethod.POST)
	public @ResponseBody Customer storeCustomer(@RequestBody Customer cust) {
	
			boolean b=custServ.storeCustomer(cust);
			if(b)
				return cust;
			else
				return null;
			
	}
	@RequestMapping(value="getAll",method=RequestMethod.GET)
	public @ResponseBody List<Customer> getAllCustomersInfo(Model m) {
		List<Customer> custList=custServ.getAllCustomers();
		m.addAttribute("custList",custList);
		return custList;
	}
}
*/