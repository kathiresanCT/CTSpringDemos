package com.cttech.service;

import java.util.List;

import com.cttech.model.Customer;

public interface ICutomerService {
	public boolean storeCustomer(Customer cust);
	public List<Customer> getAllCustomers();
	public Customer getCustomerById(int id);
	public Customer getCustomerByName(String name);
	public boolean updateCustomer(int id,Customer cust);
	public boolean deleteCustomerById(int id);
	
}
