package com.cttech.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.cttech.model.Customer;

@Repository
public class CustomerDaoImpl implements ICutomerDao{

	private JdbcTemplate jdbcTemplate;
	 
	private int storedStatus;
	
	 public void setJdbcTemplate(JdbcTemplate jdbcTemplate)
	    {
	        this.jdbcTemplate = jdbcTemplate;
	    }
	
	 int numbersNeeded=30000;
	 public Integer generateKey(){
		 Random rng = new Random();
		 Integer next = null;
		 Set<Integer> generated = new LinkedHashSet<Integer>();
		 while (generated.size() < numbersNeeded)
		 {
		     next = rng.nextInt(numbersNeeded) + 1;
		     // As we're adding to a set, this will automatically do a containment check
		     generated.add(next);
		 }
		 return next;
	 }
	@Override
	public boolean storeCustomer(Customer cust) {
		
		String sql="insert into customer(custid,name,mobile,city,gender,email) values(?,?,?,?,?,?)";
		storedStatus=jdbcTemplate.update(sql,new Object[] {generateKey(),cust.getName(),cust.getMobile(),cust.getCity(),cust.getGender(),cust.getEmail()});
		if(storedStatus==1)
			return true;
		else
			return false;
	}

	@Override
	public List<Customer> getAllCustomers() {
		System.out.println("in ge all");
		String sql="SELECT * FROM CUSTOMER";
		List<Customer> li=jdbcTemplate.query(sql,new CustomerRowMapper());
		System.out.println(li);
		return li;
		
		/*
		 *   List<Customer> customers = jdbcTemplate.query(
                sql,
                new BeanPropertyRowMapper(Customer.class));
		 * */
	}
	class CustomerRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        	Customer acc = new Customer();
        	acc.setCustId(rs.getInt(1));
        	acc.setName(rs.getString(2));
        	acc.setMobile(rs.getString(3));
        	acc.setCity(rs.getString(4));
        	acc.setGender(rs.getString(5));
        	acc.setEmail(rs.getString(6));
        	return acc;
        }
	}


	@Override
	public Customer getCustomerById(int id) {
		String sql="SELECT * FROM Customer where custid=?";
		Customer cust=(Customer)jdbcTemplate.queryForObject(sql,new Object[] {id},new CustomerRowMapper());
		return cust;
	}

	@Override
	public Customer getCustomerByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateCustomer(int id, Customer cust) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCustomerById(int id) {
		// TODO Auto-generated method stub
		return false;
	}

}
