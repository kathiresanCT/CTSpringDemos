package com.batch.demo.model;

public class Employee {

	public Employee() {
	}

	private int empId;
	private String empName;
	private String mobile;
	private Address address;

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", mobile=" + mobile +", "+this.address+ "]";
	}

	public Employee(int empId, String empName, String mobile,Address addr) {
		super();
		this.address=addr;
		this.empId = empId;
		this.empName = empName;
		this.mobile = mobile;
	}
	public Employee(Address addr) {
		System.out.println("addr-emp");
		this.address = addr;
	}
	

}
