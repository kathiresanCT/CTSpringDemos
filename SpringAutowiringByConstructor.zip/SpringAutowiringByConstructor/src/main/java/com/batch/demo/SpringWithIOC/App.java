package com.batch.demo.SpringWithIOC;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.batch.demo.model.Employee;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
    	ApplicationContext appCtx= new ClassPathXmlApplicationContext("spring-config.xml");
    	Employee cust=(Employee)appCtx.getBean("employee");
    	System.out.println(cust);
    	
    }
}
