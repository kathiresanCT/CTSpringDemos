package com.batch.demo.model;

public class Address  {

	private int pin;
	private String streetName;
	private String city;
	
	public Address(int pin, String streetName, String city) {
		super();
		this.pin = pin;
		this.streetName = streetName;
		this.city = city;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	public Address() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Address [pin=" + pin + ", streetName=" + streetName + ", city=" + city + "]";
	}
	
	
}
