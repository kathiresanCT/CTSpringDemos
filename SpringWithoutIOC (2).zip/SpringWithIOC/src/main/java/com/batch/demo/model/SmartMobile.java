package com.batch.demo.model;

public class SmartMobile extends Mobile {

	public SmartMobile() {
		// TODO Auto-generated constructor stub
	}

	public void videoCall() {
		System.out.println("calling...");
	}
}
