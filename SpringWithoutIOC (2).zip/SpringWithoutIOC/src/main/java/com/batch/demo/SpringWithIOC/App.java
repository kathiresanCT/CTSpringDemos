package com.batch.demo.SpringWithIOC;

import com.batch.demo.model.Mobile;
import com.batch.demo.model.SmartMobile;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Mobile m=null;
    	SmartMobile sm=null;
    	
    	sm=new SmartMobile();
    	m=sm;
    	m.Search("hiiii");
    	
    	
    }
}
