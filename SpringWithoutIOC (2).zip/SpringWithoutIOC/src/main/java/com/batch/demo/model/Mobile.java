package com.batch.demo.model;

public class Mobile  {

	public Mobile() {
		// TODO Auto-generated constructor stub
	}
	
	public void Search(String sn) {
		System.out.println("in search...");
	}

}
