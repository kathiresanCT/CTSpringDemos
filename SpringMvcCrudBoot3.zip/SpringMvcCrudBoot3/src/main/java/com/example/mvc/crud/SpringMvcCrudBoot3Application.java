package com.example.mvc.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcCrudBoot3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcCrudBoot3Application.class, args);
	}

}
