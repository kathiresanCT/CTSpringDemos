package com.batch.demo.dao;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.batch.demo.model.Medicine;

@Component("MedicineDaoImpl")
public class MedicineDaoImpl extends JdbcDaoSupport{

	
	@Autowired
	private DataSource dataSource;
	
	@PostConstruct
	private void initialize() {
	    setDataSource(dataSource);
	}
	
	public MedicineDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	 public void insert(Medicine med){
		
		 String sql = "INSERT INTO Medicine VALUES (?, ?, ?,?)";
		 getJdbcTemplate().update(sql,new Object[] {med.getmId(),med.getMedicineName(),med.getQuantity(),med.getPrice()});
        
		
		
	}
		  
		
}
