package com.batch.demo.model;

public class Medicine {

	private int mId;
	private String medicineName;
	private int quantity;
	private float price;
	
	
	public int getmId() {
		return mId;
	}


	public void setmId(int mId) {
		this.mId = mId;
	}


	public String getMedicineName() {
		return medicineName;
	}


	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public float getPrice() {
		return price;
	}


	public void setPrice(float price) {
		this.price = price;
	}


	public Medicine() {
		// TODO Auto-generated constructor stub
	}


	public Medicine(int mId, String medicineName, int quantity, float price) {
		super();
		this.mId = mId;
		this.medicineName = medicineName;
		this.quantity = quantity;
		this.price = price;
	}


	@Override
	public String toString() {
		return "Medicine [mId=" + mId + ", medicineName=" + medicineName + ", quantity=" + quantity + ", price=" + price
				+ "]";
	}







}
