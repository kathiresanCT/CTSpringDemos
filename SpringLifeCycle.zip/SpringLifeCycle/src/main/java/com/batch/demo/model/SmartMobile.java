package com.batch.demo.model;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class SmartMobile implements InitializingBean, DisposableBean {
	@PostConstruct
	public void before() {
		System.out.println("before");
	}

	@PreDestroy
	public void after() {
		System.out.println("after");
	}

	public SmartMobile() {
		// TODO Auto-generated constructor stub
	}

	public void videoCall() {
		System.out.println("calling...");
	}

	public void afterPropertiesSet() throws Exception {
		System.out.println("set...");
	}

	public void destroy() throws Exception {

		System.out.println("set value to null");

	}
	
	public void init() {
		System.out.println("init");
	}
	
	public void destroying() {
		System.out.println("destroyed");
	}
}
