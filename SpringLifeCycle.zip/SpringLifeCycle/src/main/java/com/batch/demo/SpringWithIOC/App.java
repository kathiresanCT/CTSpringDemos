package com.batch.demo.SpringWithIOC;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.batch.demo.model.SmartMobile;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    
    //	Resource res=new ClassPathResource("spring-config.xml");
    	//BeanFactory bf=new XmlBeanFactory(res);
    	AbstractApplicationContext bf=new ClassPathXmlApplicationContext("spring-config.xml");
    	bf.registerShutdownHook();
    	SmartMobile m=(SmartMobile)bf.getBean("myBean");
    	m.videoCall();
    	System.out.println(m);
    	
    	
    }
}
