package com.cttech.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

public class Customer {
	//javax.validation should be 2.0.2 if hib validator is 6.X
//@notblank was not available in hib validator 5.3, it was from 6.0.9
	//@NotNull
	private Integer custId;
	@NotEmpty(message="Name is mandatory")
	private String name;
	@NotEmpty(message="city is mandatory")
	private String city;
	@Pattern(regexp="[\\d]{10}",message="enter only numbers, only 10 digits")
	@NotEmpty(message="Mobile is mandatory")
	private String mobile;
	
	private String gender;
	@Email
	@NotEmpty(message="Email is mandatory")
	private String email;
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public Integer getCustId() {
		return custId;
	}

	public void setCustId(Integer custId) {
		this.custId = custId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Customer(Integer custId, String name, String city, String mobile, String gender, String email) {
		super();
		this.custId = custId;
		this.name = name;
		this.city = city;
		this.mobile = mobile;
		this.gender = gender;
		this.email = email;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", name=" + name + ", city=" + city + ", mobile=" + mobile + ", gender="
				+ gender + ", email=" + email + "]";
	}
	
}
