package com.cttech.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cttech.model.Customer;

@Repository
public class CustomerDaoImpl implements ICutomerDao{

	private JdbcTemplate jdbcTemplate;
	 
	private int storedStatus;
	
	 public void setJdbcTemplate(JdbcTemplate jdbcTemplate)
	    {
	        this.jdbcTemplate = jdbcTemplate;
	    }
	
	@Override
	public boolean storeCustomer(Customer cust) {
		String sql="insert into customer(custid,name,mobile,city,gender,email) values(?,?,?,?,?,?)";
		storedStatus=jdbcTemplate.update(sql,new Object[] {1001,cust.getName(),cust.getMobile(),cust.getCity(),cust.getGender(),cust.getEmail()});
		if(storedStatus==1)
			return true;
		else
			return false;
	}

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer getCustomerById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer getCustomerByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateCustomer(int id, Customer cust) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCustomerById(int id) {
		// TODO Auto-generated method stub
		return false;
	}

}
