package com.cttech.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cttech.dao.ICutomerDao;
import com.cttech.model.Customer;

@Service
public class CustomerServiceImpl implements ICutomerService{
	
	@Autowired
	private ICutomerDao custDao;
	
	boolean status=false;
	
	@Override
	public boolean storeCustomer(Customer cust) {
		status=custDao.storeCustomer(cust);
		return status;
	}

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer getCustomerById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer getCustomerByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateCustomer(int id, Customer cust) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCustomerById(int id) {
		// TODO Auto-generated method stub
		return false;
	}

}
