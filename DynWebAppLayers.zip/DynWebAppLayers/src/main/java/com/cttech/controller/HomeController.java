package com.cttech.controller;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cttech.model.Customer;
import com.cttech.service.ICutomerService;

@Controller
public class HomeController {

	@Autowired
	private ICutomerService custServ;
	
	@RequestMapping(value= {"/","homepage","home.aspx","home.php"})
	public String displayHomePage() {
		return "home";
	}
	@RequestMapping(value="register",method=RequestMethod.GET)
	public String displayRegisterPage(Model m) {
		List<String> cityList=Arrays.asList("Mumbai","Pune","Hyderabad","Chennai");
		m.addAttribute("cityList",cityList);
		m.addAttribute("customer", new Customer());
		return "register";
	}
	@RequestMapping(value="register",method=RequestMethod.POST)
	public String storeCustomer(Model m,@Valid @ModelAttribute("customer") Customer cust,BindingResult br) {
		String view=null;
		if(br.hasErrors())
		{
			view="register";
		}
		else
		{
			boolean b=custServ.storeCustomer(cust);
			if(b==true)
			view="success";
			else
			view="home";
		}
		
		return view;
	}
}
