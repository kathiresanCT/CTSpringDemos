package com.batch.demo.SpringBasic1;

public class Student {

	private int id;
	private String name;
	private Address address;
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Student() {
	System.out.println("called");
	}
	public void display() {
		System.out.println("hello");
	}
}
