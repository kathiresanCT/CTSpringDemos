package com.batch.demo.SpringBasic1;

public class Address {

	int id;
	
	public Address() {
		System.out.println("in no arg");
	}
	public Address(int id) {
		System.out.println("in");
		this.id=id;
	}
	
}
