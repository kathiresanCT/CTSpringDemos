package com.ct.latest.demos.SpringJdbcBankApplication.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.ct.latest.demos.SpringJdbcBankApplication.model.Account;
@Component("daoImpl")
public class AccountDaoImpl implements IAccountDaoImpl {

	/*
	 * public void setDataSource(DataSource dataSource) {
	      this.dataSource = dataSource;
	      this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	   }
	 * */
		private DataSource dataSource;
		@Autowired
		public void setDataSource(DataSource ds) {
			this.dataSource=ds;
			//create the jdbcTempl obj inside each method
		}
		
	public void createAccount(Account account) {
		String qry="INSERT INTO Account VALUES(?,?,?,?,?,?)";
		
		JdbcTemplate insert = new JdbcTemplate(dataSource);	
		insert.update(qry, account.getAccountId(),account.getAccountHolderName(),account.getLastName(),account.getBalance(),account.getOpeningBalance(),account.getMobileNumber());
		System.out.println("stored...");
	return;	
	/*
	   // define query arguments
        Object[] params = new Object[] { name, surname, title, new Date() };
         
        // define SQL types of the arguments
        int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP };
 */
	}

	public boolean deleteAccount(int accountId) {
		// TODO Auto-generated method stub
		return false;
	}

	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return null;
	}

	public Account getAccountDetailsByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public Account getAccountDetailsById(int accountId) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean updateDetailsByName(String name) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean updateDetailsById(String name) {
		// TODO Auto-generated method stub
		return false;
	}

}
