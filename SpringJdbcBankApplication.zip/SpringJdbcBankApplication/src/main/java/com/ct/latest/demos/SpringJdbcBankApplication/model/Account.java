package com.ct.latest.demos.SpringJdbcBankApplication.model;

public class Account {
	private int accountId;
	private String accountHolderName;
    private String lastName;
    private float balance;
    private float openingBalance;
    private String mobileNumber;
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	public float getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(float openingBalance) {
		this.openingBalance = openingBalance;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Account(int accountId, String accountHolderName, String lastName, float balance, float openingBalance,
			String mobileNumber) {
		super();
		this.accountId = accountId;
		this.accountHolderName = accountHolderName;
		this.lastName = lastName;
		this.balance = balance;
		this.openingBalance = openingBalance;
		this.mobileNumber = mobileNumber;
	}

}
