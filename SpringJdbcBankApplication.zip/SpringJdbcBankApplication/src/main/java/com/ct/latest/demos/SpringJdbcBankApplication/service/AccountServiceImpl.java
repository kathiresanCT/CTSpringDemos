package com.ct.latest.demos.SpringJdbcBankApplication.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ct.latest.demos.SpringJdbcBankApplication.dao.IAccountDaoImpl;
import com.ct.latest.demos.SpringJdbcBankApplication.model.Account;
@Component("accountService")
public class AccountServiceImpl implements IAccountService {

	@Autowired
	private IAccountDaoImpl daoImpl;
	
	public void createAccount(Account account) {
		daoImpl.createAccount(account);		
	}

	public boolean deleteAccount(int accountId) {
		
		return false;
	}

	public List<Account> getAllAccounts() {
		
		return null;
	}

	public Account getAccountDetailsByName(String name) {
		
		return null;
	}

	public Account getAccountDetailsById(int accountId) {
		
		return null;
	}

	public boolean updateDetailsByName(String name) {
		
		return false;
	}

	public boolean updateDetailsById(String name) {
		
		return false;
	}

}
