package com.batch.demo.service;

import org.springframework.stereotype.Component;

@Component("medServ")
public class MedicineServiceImpl {

	public MedicineServiceImpl() {
		// TODO Auto-generated constructor stub
	}

}
