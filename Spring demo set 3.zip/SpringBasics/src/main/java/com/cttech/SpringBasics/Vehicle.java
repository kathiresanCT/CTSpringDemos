package com.cttech.SpringBasics;

import org.springframework.stereotype.Component;

@Component("vehicle")	
public class Vehicle {

	public void display() {
		System.out.println("display...");
	}
}
