package com.cttech.SpringAopDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cttech.SpringAopDemo.service.EnterpriseService;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
      ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
      EnterpriseService ep= app.getBean("entService",EnterpriseService.class);
     // System.out.println("company name : "+ep.getCompany().getName());
      System.out.println("department : "+ep.getDepartment().getName());
    }
}
