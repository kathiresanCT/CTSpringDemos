package com.cttech.SpringAopDemo.model;

public class Department {

	private int deptId;
	private String name;
	
	public Department() {
		// TODO Auto-generated constructor stub
	}

	public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Department(int deptId, String name) {
		super();
		this.deptId = deptId;
		this.name = name;
	}

	@Override
	public String toString() {
		return "Department [deptId=" + deptId + ", deptName=" + name + "]";
	}
	
	
}
