package com.cttech.controller;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class UploadController {

	@Autowired
	ServletContext context;

	@RequestMapping("/")
	public String getPage() {
		return "index";
	}

	@RequestMapping("/uploadPage")
	public String getUploadPage() {
		return "upload";
	}

	@RequestMapping(value = "/upload", method = RequestMethod.POST)
	public @ResponseBody String uploadFileHandler(@RequestParam("name") String name) {
		return "success";
	}

	@Deprecated
	@RequestMapping(value = { "/oldLogin" })
	public String oldLogin(Model model) {
		// Code here never run.
		return "login";
	}
	@RequestMapping(value = { "/login" })
	public String newLogin(Model model) {
		// Code here never run.
		return "login";
	}
}
 