package com.cttech.interceptor;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Collection;

import javax.imageio.ImageIO;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class ImageWaterMarkInterceptor extends HandlerInterceptorAdapter {

	@Autowired
	ServletContext context;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		String name = request.getParameter("name");
		final MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;

		MultipartFile file = multiRequest.getFile("file");
		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();

				// Creating the directory to store file
				// String rootPath = System.getProperty("catalina.home");
				String relativeWebPath = "/resources/avatars";
				String absoluteFilePath = context.getRealPath(relativeWebPath);
				File uploadedFile = new File(absoluteFilePath + File.separator);
				// File dir = new File(rootPath + File.separator + "tmpFiles");

				if (!uploadedFile.exists())
					uploadedFile.mkdirs();

				// Create the file on server
				File serverFile = new File(uploadedFile.getAbsolutePath() + File.separator + name + ".jpg");
				File waterMarkedFile = new File(
						uploadedFile.getAbsolutePath() + File.separator + name + "waterMarked" + ".jpg");
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.flush();
				stream.close();
				System.out.println(serverFile.getAbsolutePath());

				addTextWatermark("CtTech.com", "jpg", serverFile, waterMarkedFile);
				// return "You successfully uploaded file=" + name;
			} catch (Exception e) {
				e.printStackTrace();
				// return "You failed to upload " + name + " => " + e.getMessage();
			}
		} else {
			System.out.println("You failed to upload " + name + " because the file was empty.");
		}

		System.out.println("Inside pre handle");
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {

		System.out.println("Inside post handle");
	}

	private static void addTextWatermark(String text, String type, File source, File destination) throws IOException {
		BufferedImage image = ImageIO.read(source);
		System.out.println(image.getType());
		// determine image type and handle correct transparency
		int imageType = "png".equalsIgnoreCase(type) ? BufferedImage.TYPE_INT_ARGB : BufferedImage.TYPE_INT_RGB;
		BufferedImage watermarked = new BufferedImage(image.getWidth(), image.getHeight(), imageType);

		// initializes necessary graphic properties
		Graphics2D w = (Graphics2D) watermarked.getGraphics();
		w.drawImage(image, 0, 0, null);
		AlphaComposite alphaChannel = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.4f);
		w.setComposite(alphaChannel);
		w.setColor(Color.GRAY);
		w.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 46));
		FontMetrics fontMetrics = w.getFontMetrics();
		Rectangle2D rect = fontMetrics.getStringBounds(text, w);

		// calculate center of the image
		int centerX = (image.getWidth() - (int) rect.getWidth()) / 2;
		int centerY = image.getHeight() / 2;

		// add text overlay to the image
		w.drawString(text, centerX, centerY);
		ImageIO.write(watermarked, type, destination);
		w.dispose();
	}
}
/*
 * 
 * 
 * @RequestMapping(value = "/upload", method = RequestMethod.POST)
 * public @ResponseBody String uploadFileHandler(@RequestParam("name") String
 * name,
 * 
 * @RequestParam("file") MultipartFile file) {
 * 
 * if (!file.isEmpty()) { try { byte[] bytes = file.getBytes();
 * 
 * // Creating the directory to store file // String rootPath =
 * System.getProperty("catalina.home"); String relativeWebPath =
 * "/resources/avatars"; String absoluteFilePath =
 * context.getRealPath(relativeWebPath); File uploadedFile = new
 * File(absoluteFilePath + File.separator); // File dir = new File(rootPath +
 * File.separator + "tmpFiles");
 * 
 * if (!uploadedFile.exists()) uploadedFile.mkdirs();
 * 
 * // Create the file on server File serverFile = new
 * File(uploadedFile.getAbsolutePath() + File.separator + name + ".jpg"); File
 * waterMarkedFile = new File( uploadedFile.getAbsolutePath() + File.separator +
 * name + "waterMarked" + ".jpg"); BufferedOutputStream stream = new
 * BufferedOutputStream(new FileOutputStream(serverFile)); stream.write(bytes);
 * stream.flush(); stream.close();
 * System.out.println(serverFile.getAbsolutePath());
 * 
 * addTextWatermark("CtTech.com", "jpg", serverFile, waterMarkedFile); return
 * "You successfully uploaded file=" + name; } catch (Exception e) {
 * e.printStackTrace(); return "You failed to upload " + name + " => " +
 * e.getMessage(); } } else { return "You failed to upload " + name +
 * " because the file was empty."; } }
 * 
 * private static void addTextWatermark(String text, String type, File source,
 * File destination) throws IOException { BufferedImage image =
 * ImageIO.read(source); System.out.println(image.getType()); // determine image
 * type and handle correct transparency int imageType =
 * "png".equalsIgnoreCase(type) ? BufferedImage.TYPE_INT_ARGB :
 * BufferedImage.TYPE_INT_RGB; BufferedImage watermarked = new
 * BufferedImage(image.getWidth(), image.getHeight(), imageType);
 * 
 * // initializes necessary graphic properties Graphics2D w = (Graphics2D)
 * watermarked.getGraphics(); w.drawImage(image, 0, 0, null); AlphaComposite
 * alphaChannel = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.4f);
 * w.setComposite(alphaChannel); w.setColor(Color.GRAY); w.setFont(new
 * Font(Font.SANS_SERIF, Font.BOLD, 26)); FontMetrics fontMetrics =
 * w.getFontMetrics(); Rectangle2D rect = fontMetrics.getStringBounds(text, w);
 * 
 * // calculate center of the image int centerX = (image.getWidth() - (int)
 * rect.getWidth()) / 2; int centerY = image.getHeight() / 2;
 * 
 * // add text overlay to the image w.drawString(text, centerX, centerY);
 * ImageIO.write(watermarked, type, destination); w.dispose(); } }
 */
