package com.cttech.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class LoggingAspect {
	
	@Before("execution(public void com.cttech.model.FreeAccount.register())")
	public void logAdvice() {
		System.out.println("advice called...");
		System.out.println("no need to wait....");
		System.out.println("please subscribe to Premium account!!!");
	}

}
