package com.cttech.model;

public class Account {

	public void register(){
		System.out.print("Registered !!! ");
	}
	
	public void searchForFreeBooks(){
		System.out.println("Searching in free books!!!");
	}
}
