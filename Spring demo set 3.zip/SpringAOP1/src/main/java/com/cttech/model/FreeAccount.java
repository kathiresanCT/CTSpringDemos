package com.cttech.model;

public class FreeAccount extends Account{

	@Override
	public void register(){
		super.register();
		System.out.println("As Free User!!!");
	}
	
	
}
