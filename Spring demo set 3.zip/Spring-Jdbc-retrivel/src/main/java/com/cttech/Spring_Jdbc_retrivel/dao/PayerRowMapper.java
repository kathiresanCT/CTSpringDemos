package com.cttech.Spring_Jdbc_retrivel.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cttech.Spring_Jdbc_retrivel.model.Payer;

public class PayerRowMapper implements RowMapper<Payer> {

	@Override
	public Payer mapRow(ResultSet rs, int rowNum) throws SQLException {
		Payer payer=new Payer();
		payer.setPayerId(rs.getInt(1));
		payer.setPayerName(rs.getString(2));
		payer.setPayerMobile(rs.getString(3));
		payer.setPayerCity(rs.getString(4));
		return payer;
	}
	

}
