package com.cttech.Spring_Jdbc_retrivel.model;

public class Payer {

	private String payerName;
	private String payerCity;
	private String payerMobile;
	private int payerId;
	
	public String getPayerName() {
		return payerName;
	}

	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}

	public String getPayerCity() {
		return payerCity;
	}

	public void setPayerCity(String payerCity) {
		this.payerCity = payerCity;
	}

	public String getPayerMobile() {
		return payerMobile;
	}

	public void setPayerMobile(String payerMobile) {
		this.payerMobile = payerMobile;
	}

	public int getPayerId() {
		return payerId;
	}

	public void setPayerId(int payerId) {
		this.payerId = payerId;
	}

	public Payer() {
		// TODO Auto-generated constructor stub
	}

	public Payer(String payerName, String payerCity, String payerMobile, int payerId) {
		super();
		this.payerName = payerName;
		this.payerCity = payerCity;
		this.payerMobile = payerMobile;
		this.payerId = payerId;
	}

	@Override
	public String toString() {
		return "Payer [payerName=" + payerName + ", payerCity=" + payerCity + ", payerMobile=" + payerMobile
				+ ", payerId=" + payerId + "]";
	}
	
	
	
}
