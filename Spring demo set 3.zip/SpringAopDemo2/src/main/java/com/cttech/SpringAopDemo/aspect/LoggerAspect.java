package com.cttech.SpringAopDemo.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class LoggerAspect {
	@After("logForAllGetters()")
	public void loggingInfoAfter() {
		System.out.println("calling aspect logging after :: "+System.currentTimeMillis());
		//return 0;
	}
	
	@Before("logForAllGetters()")
	public void loggingInfoBefore() {
		System.out.println("calling aspect logging before :: "+System.currentTimeMillis());
		//return 0;
	}
	
	@Pointcut(value="execution(*com.cttech.SpringAopDemo.model.* get*(..))")
	public void logForAllGetters() {
//		System.out.println("in pointCut logging :: "+System.currentTimeMillis());
		//return 0;
	}
}
