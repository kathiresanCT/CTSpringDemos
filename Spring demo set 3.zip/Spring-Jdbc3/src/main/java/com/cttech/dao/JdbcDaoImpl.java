package com.cttech.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cttech.model.Patient;
@Component("jdbcObj")
public class JdbcDaoImpl {

	private DataSource ds;
	
	private JdbcTemplate jdbc=null;
	
	public DataSource getDs() {
		return ds;
	}
//to create obj using setter autowired is used
	@Autowired
	public void setDs(DataSource dataSource) {
		this.jdbc=new JdbcTemplate(dataSource);
		
	}
	Connection conn=null;
	//creating connection pooling driverManager datasource
	//not good for production env
	public Patient getPatent(int patientID) throws SQLException {
		conn=ds.getConnection();
		//String driver="com.mysql.jdbc.Driver";
		//conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
		PreparedStatement st=conn.prepareStatement("SELECT * FROM Patient where pid=?");
		st.setInt(1, patientID);
		Patient p=null;
	
		ResultSet rs=st.executeQuery();
				if(rs.next()) {
					p=new Patient(patientID,rs.getString(2));
				}
				rs.close();
				st.close();
		return p;
	}
	
	public int getPatientCount() {
		
		String sql="select count(*) from patient ";
		
		//jdbc.setDataSource(getDs());
		return jdbc.queryForInt(sql);
	}
	
}
