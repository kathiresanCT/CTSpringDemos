package com.cttech.model;

import java.util.List;

public class EmployeeForm {

	private List<Employee> contacts;

	public List<Employee> getContacts() {
		return contacts;
	}

	public void setContacts(List<Employee> contacts) {
		this.contacts = contacts;
	}

}
