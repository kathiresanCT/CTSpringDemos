package com.cttech.dao;

import com.cttech.model.Employee;

public interface IEmployeeDao {
	public boolean checkLogin(Employee emp);
	public boolean register(Employee emp);

}
