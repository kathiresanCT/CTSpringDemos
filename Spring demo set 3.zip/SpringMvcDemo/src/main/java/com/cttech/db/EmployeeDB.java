package com.cttech.db;

import java.util.HashMap;

import com.cttech.model.Employee;

public class EmployeeDB {

	static HashMap<String,Employee> empList=new HashMap<>();
	
	public static HashMap<String,Employee> getEmployeeData(){
		Employee e1=new Employee("ajay", "a@ct.com", "ajay");
		Employee e2=new Employee("jay", "jay@ct.com", "jay");
		Employee e3=new Employee("kumar", "kumar@ct.com", "kumar");
		Employee e4=new Employee("wilson", "wilson@ct.com", "wilson");
		empList.put(e1.getName(),e1 );
		empList.put(e2.getName(),e2 );
		empList.put(e3.getName(),e3 );
		empList.put(e4.getName(),e4 );	
		return empList;
	}
}
