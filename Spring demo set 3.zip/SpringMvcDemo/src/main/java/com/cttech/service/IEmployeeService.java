package com.cttech.service;

import java.util.HashMap;

import com.cttech.model.Employee;

public interface IEmployeeService {

	public boolean checkLogin(Employee emp);
	public boolean register(Employee emp);
	
	
}
