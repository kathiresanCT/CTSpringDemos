package com.cttech.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.cttech.dao.IEmployeeDao;
import com.cttech.model.Employee;

@Service
@Scope("prototype")
public class EmployeeService implements IEmployeeService {
	public EmployeeService(){
		System.out.println("in emp service "+hashCode());
	}
	@Autowired
	private IEmployeeDao emplDao;


	@Override
	public boolean checkLogin(Employee emp) {

		return emplDao.checkLogin(emp);
	}

	@Override
	public boolean register(Employee emp) {
		
		return emplDao.register(emp);
	}

}
