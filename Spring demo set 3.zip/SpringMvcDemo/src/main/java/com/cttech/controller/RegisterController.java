package com.cttech.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cttech.model.Employee;
import com.cttech.service.EmployeeService;


@Controller
@Scope("request")
public class RegisterController {
	@Autowired
	private EmployeeService empService;

	public EmployeeService getEmpService() {
		return empService;
	}
	
	public RegisterController() {
	System.out.println("in reg ctlr");
	System.out.println(hashCode());
	System.out.println("in ctlr - serv- "+empService);
	}

	@RequestMapping("/register")
	public String getRegisterPage(Model m) {
		m.addAttribute("employee",new Employee());
		return "register";
	}
	@RequestMapping(value="/register",method=RequestMethod.POST)
	public ModelAndView registerEmployee(@ModelAttribute("employee") Employee employee, BindingResult br) {
		String path = null;
		ModelAndView mv=new ModelAndView();
		boolean storedStatus = false;
		System.out.println("in reg");
		if (br.hasErrors()) {
			path = "error";
		} else {
			System.out.println(empService.hashCode());
			storedStatus = empService.register(employee);
			if (storedStatus) 
			{
				path = "success";
				mv.addObject("empData",employee.getName()+" account registered!!!");
			} else 
			{
				path = "error";
			}
		}
		 mv.setViewName(path);
		 return mv;
	}
}
