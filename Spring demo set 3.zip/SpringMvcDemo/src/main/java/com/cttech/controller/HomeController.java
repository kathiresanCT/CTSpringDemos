package com.cttech.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cttech.model.Employee;
import com.cttech.service.IEmployeeService;

@Controller
public class HomeController {

	@Autowired
	private IEmployeeService empService;
	
	@RequestMapping("/")
	public String getHome() {
		return "index";
	}

	@RequestMapping("/home")
	public ModelAndView getHomeLanding() {
		return new ModelAndView("home");
	}

	@RequestMapping("/signin")
	public ModelAndView getLoginPage(Model m) {
		m.addAttribute("empl", new Employee());
		return new ModelAndView("login");
	}

	/*
	 * @RequestMapping("/loginCheck") public ModelAndView
	 * checkLoginPage(@RequestParam("email") String email,@RequestParam("pwd")
	 * String pass) { String path=null; String message=null;
	 * 
	 * if("user1@ct.com".equalsIgnoreCase(email) && "user1".equals(pass)) {
	 * path="success"; message="Logged In Successfully"; } else { path="error";
	 * message="Login Failed!!!"; }
	 * 
	 * return new ModelAndView(path); }
	 */
	@RequestMapping("/loginCheck")
	public ModelAndView checkLoginPage(@ModelAttribute Employee employee, BindingResult br) {
		String path = null;
		String message = null;
		boolean status=false;
		if (br.hasErrors()) {
			path = "error";
		} 
		else
		{
			System.out.println("in ctl "+employee.getPassword());
			status=empService.checkLogin(employee);
			if(status) {
				path = "success";
				message = "Logged In Successfully";
			}
			else {
				path = "error";
				message = "Login Failed!!!";
			}
		}
		return new ModelAndView(path);
	}
}