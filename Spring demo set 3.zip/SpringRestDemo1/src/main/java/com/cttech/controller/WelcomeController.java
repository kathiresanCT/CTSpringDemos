package com.cttech.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WelcomeController {

	@Autowired
	private VehicleServiceImpl vserv;
	
//	@RequestMapping("/")
//	public String getHomePage() {
//		return "index";
//	}
	
	//@RequestMapping(method = RequestMethod.GET) = @GetMapping
	@GetMapping(value="/",headers="Accept=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
	public Map<String, Vehicle> getAllVehicleData()
	{
		return vserv.getAllVeicleData();
	}
	@PostMapping(value="/store",headers="Accept=application/json", consumes = MediaType.APPLICATION_JSON_VALUE)
	public Map<String, Vehicle> storeVehicleData(@RequestBody Vehicle vehicle)
	{
		vserv.getAllVeicleData().put(vehicle.getVehId(), vehicle);
		return vserv.getAllVeicleData();
	}
	
	
}
