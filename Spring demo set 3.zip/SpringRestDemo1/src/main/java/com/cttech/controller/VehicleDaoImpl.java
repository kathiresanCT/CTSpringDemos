package com.cttech.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public class VehicleDaoImpl {

	private HashMap<String, Vehicle> vehList = new HashMap<>();
	Vehicle v1, v2, v3 = null;

	public VehicleDaoImpl() {
		v1 = new Vehicle("101", "ACE");
		v2 = new Vehicle("102", "ACE 407");
		v3 = new Vehicle("103", "ACE 707");
	}

	public Map<String, Vehicle> getAllVeicleData() {

		vehList.put(v1.getVehId(), v1);
		vehList.put(v2.getVehId(), v2);
		vehList.put(v3.getVehId(), v3);

		return vehList;
	}

	
	
}
