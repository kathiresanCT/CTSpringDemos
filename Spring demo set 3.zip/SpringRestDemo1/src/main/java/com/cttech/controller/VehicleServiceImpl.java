package com.cttech.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VehicleServiceImpl {

	@Autowired
	private VehicleDaoImpl vdao;
	
	public Map<String, Vehicle> getAllVeicleData()
	{
		return vdao.getAllVeicleData();
	}
}
