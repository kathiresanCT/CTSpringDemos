package com.cttech.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cttech.model.Patient;

public class JdbcDaoImpl {

	public Patient getPatent(int patientID) {
		Patient p = null;
		try {	System.out.println("in get");
		int cid = 1001;
		Connection conn = null;
		String driver = "com.mysql.jdbc.Driver";
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");
		PreparedStatement st = conn.prepareStatement("SELECT * FROM Patient where pid=?");
		
		st.setInt(1, cid);
			ResultSet rs = st.executeQuery();
		//	System.out.println(rs);
		while(rs.next()) {
			System.out.println("in while");
			p = new Patient(cid, rs.getString(2));
			System.out.println(p);
		}
		rs.close();
		st.close();
		
	}catch(Exception sql) {
		sql.printStackTrace();
	}
	return p;
	}
}
