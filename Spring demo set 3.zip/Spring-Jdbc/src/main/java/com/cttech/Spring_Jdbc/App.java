package com.cttech.Spring_Jdbc;

import java.sql.SQLException;

import com.cttech.dao.JdbcDaoImpl;
import com.cttech.model.Patient;

public class App 
{
    public static void main( String[] args ) throws SQLException
    {
        Patient p=new JdbcDaoImpl().getPatent(1);
        System.out.println(p);
    }
}
