//package com.cttech.dao;
//
//import java.util.HashMap;
//
//import org.springframework.stereotype.Repository;
//
//import com.cttech.db.EmployeeDB;
//import com.cttech.model.Employee;
//
//@Repository
//public class EmployeeDao implements IEmployeeDao {
//
//	boolean status = false;
//
//	public EmployeeDao() {
//
//	}
//
//	@Override
//	public boolean checkLogin(Employee employee) {
//		System.out.println(employee.getEmail() + " " + employee.getPassword());
//		if ("user1@ct.com".equalsIgnoreCase(employee.getEmail().trim())
//				&& "user1".equals(employee.getPassword().trim())) {
//
//			status = true;
//
//		}
//		System.out.println(status);
//		return status;
//	}
//
//	@Override
//	public boolean register(Employee emp) {
//
//		EmployeeDB.getEmployeeData().put(emp.getName(), emp);
//		return true;
//	}
//
//}
