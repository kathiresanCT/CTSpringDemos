package com.cttech.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cttech.model.Employee;
import com.cttech.model.EmployeeForm;

@Controller
public class HomeController {
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String getUsers(Model model) throws Exception {
		List<Employee> users = getListOfUsers();
		EmployeeForm empList = new EmployeeForm();
		empList.setUsers(users);
		model.addAttribute("Users", empList);
		return "showusers";
	}

	@RequestMapping(value = "saveUsers", method = RequestMethod.POST)
	public String postUsers(@ModelAttribute("Users") EmployeeForm emp ,Model model) throws Exception {
		System.out.println(emp.getUsers().size());
		List<Employee> users = getListOfUsers();
		System.out.println("after "+emp.getUsers());
//		EmployeeForm empList = emp;
//		System.out.println(emp.equals(empList));
//		empList.setUsers(emp.getUsers());
		model.addAttribute("Users", emp.getUsers());
		return "success";
	}
	
	// Dummy method for adding List of Users
	private List<Employee> getListOfUsers() {
		List<Employee> emps = new ArrayList<Employee>();
		emps.add(new Employee("Jack", "Reacher", "abc@xyz.com"));
		emps.add(new Employee("Remington", "Steele", "rs@cbd.com"));
		emps.add(new Employee("Jonathan", "Raven", "jr@sn.com"));
		return emps;
	}

}