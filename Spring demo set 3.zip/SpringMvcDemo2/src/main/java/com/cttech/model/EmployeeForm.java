package com.cttech.model;

import java.util.List;

public class EmployeeForm {

	private List<Employee> users;

	public List<Employee> getUsers() {
		return users;
	}

	public void setUsers(List<Employee> users) {
		this.users = users;
	}

}
